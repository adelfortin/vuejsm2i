<template>
    <router-view :tasks="'heyy'"/>
    <router-link to="/">Home</router-link> |
    <router-link to="/about">About</router-link>
    <TaskAdd @addTaskEvent="addTask"/>
    <TaskList :tasks="taskList" @removeTaskEvent="removeTask"/>
</template>

<script>

import TaskList from "@/components/TaskList.vue";
import TaskAdd from "@/components/TaskAdd.vue";

export default {
    name: 'App',
    components: {TaskAdd, TaskList},
    data : () => {
        return {
            taskList : [],
        }
    },
    methods : {
        addTask(newTaskName) {
            this.taskList.push(newTaskName);
        },
        removeTask(targetIndex) {
            this.taskList.splice(targetIndex, 1);
        }
    }
}
</script>

<style>
#app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #2c3e50;
    margin-top: 60px;
}
</style>
