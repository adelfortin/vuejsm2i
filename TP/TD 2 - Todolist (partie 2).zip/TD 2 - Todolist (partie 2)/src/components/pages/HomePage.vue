<template>
    <h2>Page home</h2>
</template>

<script>

export default {
    name : 'HomePage',
    mounted() {
        console.log(this.works)
    },
    props : ['works']
}
</script>
