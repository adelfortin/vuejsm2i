<template>
    <h2>About home</h2>
</template>

<script>
export default {
    name : 'AboutPage',
    props : ['works'],
    mounted() {
    }
}
</script>
