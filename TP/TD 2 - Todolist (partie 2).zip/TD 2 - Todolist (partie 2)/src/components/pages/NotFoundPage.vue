<template>
    <h2>404 : Page not found </h2>
</template>

<script>
export default {
    name : 'NotFoundPage'
}
</script>
