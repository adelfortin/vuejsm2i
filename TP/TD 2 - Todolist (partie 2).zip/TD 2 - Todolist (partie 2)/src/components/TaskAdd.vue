<template>
    <div>
        <input type="text" v-model="newTaskName">

        <button @click="handleAddTask">Ajouter</button>
    </div>
</template>

<script>
    export default {
        name: 'TaskAdd',
        data : () => {
            return {
                newTaskName : '',
            }
        },
        methods : {
            handleAddTask() {
                this.$emit('addTaskEvent', this.newTaskName);
                this.newTaskName = '';
            }
        }
    }
</script>

<style scoped>
    div {
        display: flex;
        justify-content: center;
    }
</style>
