<template>
    <div class="container">
        <ul class="list" v-if="tasks.length > 0">
            <li v-for="(task, id) in tasks" :key="task">
                {{ task }}

                <button @click="handleRemoveTask" :data-target-id="id">supprimer</button>
            </li>
        </ul>

        <p v-if="tasks.length === 0">
            La liste des tâches est vide
        </p>
    </div>
</template>

<script>
export default {
    name : 'TaskList',
    props: ['tasks'],
    methods : {
        handleRemoveTask(event) {
            this.$emit('removeTaskEvent', event.target.dataset.targetId);
        }
    }
}
</script>

<style scoped>
    .container {
        display: flex;
        justify-content: center;
    }

    .list {
        width: 600px;
        border: 1px solid #CCC;
        padding: 10px;
        list-style: none;
    }

    .list li {
        display: flex;
        justify-content: space-between;
        margin: 10px 0;
        border-bottom: 1px solid #EEE;
    }
</style>
