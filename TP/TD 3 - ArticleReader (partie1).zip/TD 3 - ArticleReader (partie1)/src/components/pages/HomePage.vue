<template>
    <div class="article-container">
        <div class="article" v-for="article in articleListSorted" :key="article.id">
            <p>{{ article.title }}</p>

            <router-link :to="'article/' + article.id">Voir plus</router-link>
        </div>
    </div>

</template>

<script>
    export default {
        name: 'HomePage',
        data() {
            return {
                articleList : []
            }
        },
        methods : {
        },
        mounted() {
            fetch('https://jsonplaceholder.typicode.com/posts')
                .then(res => res.json())
                .then((data) => {
                    this.articleList = data;
                });
        },
        computed : {
            articleListSorted() {
                return [...this.articleList].sort((a, b) => {
                    return a.title.localeCompare(b.title);
                });
            }
        }
    }
</script>

<style scoped>
    .article-container {
        display: flex;
        flex-wrap: wrap;
    }

    .article {
        padding: 10px;
        border: 1px solid #EEE;
        margin: 20px;
    }
</style>
