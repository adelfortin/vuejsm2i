<template>
    <div>

    </div>
</template>

<script>
    export default {
        name: 'ArticleDetailsPage',
        data() {
            return {
                targetArticle : null
            }
        },
        mounted() {

        }
    }
</script>
