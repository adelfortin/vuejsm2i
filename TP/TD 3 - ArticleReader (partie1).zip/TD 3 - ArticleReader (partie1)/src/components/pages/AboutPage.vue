<template lang="html">

  <section class="src-components-pages-about-page">
    <h1>src-components-pages-about-page Component</h1>
  </section>

</template>

<script lang="js">

  export default  {
    name: 'src-components-pages-about-page',
    props: [],
    mounted () {

    },
    data () {
      return {

      }
    },
    methods: {

    },
    computed: {

    }
}


</script>

<style scoped lang="scss">
  .src-components-pages-about-page {

  }
</style>
