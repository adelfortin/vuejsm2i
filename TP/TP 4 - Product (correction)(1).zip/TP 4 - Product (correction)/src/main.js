import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import {createStore} from "vuex";

const store = createStore({
    state() {
        return {
            products : [{
                id: 1,
                name: 'car',
                price: 500
            },{
                id: 2,
                name: 'house',
                price: 1500
            }]
        }
    },
    mutations : {
        addProduct(state, {name, product}) {
            const productLength = state.products.length;
            state.products.push({
                id: productLength === 0 ? 0 : state.products[state.products.length - 1].id + 1,
                name,
                product
            });
        }
    }
})

createApp(App).use(router).use(store).mount('#app')
