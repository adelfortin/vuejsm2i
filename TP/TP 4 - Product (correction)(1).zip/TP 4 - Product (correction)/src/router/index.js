import {createRouter, createWebHistory} from 'vue-router'
import HomePage from "@/components/pages/HomePage.vue";
import CreateProductPage from "@/components/pages/CreateProductPage.vue";

const routes = [{
    path: '/', component: HomePage
},{
    path: '/create-product', component: CreateProductPage
}]

const router = createRouter({
    history: createWebHistory(process.env.BASE_URL),
    routes
})

export default router
