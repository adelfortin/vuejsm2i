<template lang="html">
    <div>
        <ul>
            <li v-for="product in products" :key="product.id">
                {{ product.name }}
            </li>
        </ul>
    </div>
</template>

<script lang="js">

  import {mapState} from "vuex";

  export default  {
    name: 'HomePage',
    props: [],
    mounted () {

    },
    data () {
      return {

      }
    },
    methods: {

    },
    computed: {
        ...mapState(['products'])
    }
}


</script>

<style scoped lang="scss">

</style>
