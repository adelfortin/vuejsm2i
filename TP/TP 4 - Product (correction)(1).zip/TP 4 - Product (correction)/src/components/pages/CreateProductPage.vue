<template lang="html">
    <div>
        <h1>Crée un produit</h1>

        <input type="text" placeholder="nom du produit" v-model="newProductName"/>

        <input type="number" placeholder="price du produit" v-model="newProductPrice"/>

        <button @click="handleAddProduct">Ajouter</button>
    </div>
</template>

<script lang="js">

import {mapMutations} from "vuex";

export default {
    name: 'CreateProductPage',
    props: [],
    mounted() {

    },
    data() {
        return {
            newProductName : '',
            newProductPrice : 0,
        }
    },
    methods: {
        ...mapMutations(['addProduct']),
        handleAddProduct() {
            this.addProduct({name: this.newProductName, price : this.newProductPrice});
            this.$router.push('/');
        }
    },
    computed: {}
}
</script>

<style scoped></style>
