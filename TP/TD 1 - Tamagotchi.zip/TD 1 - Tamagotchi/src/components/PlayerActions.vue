<template>
    <button @click="handleAction" data-target-stat="satiety">MANGER</button>
    <button @click="handleAction" data-target-stat="stamina">DORMIR</button>
    <button @click="handleAction" data-target-stat="fun">JOUER</button>
</template>

<script>
    export default {
        name: 'PlayerActions',
        methods : {
            handleAction(event) {
                const targetDataset = event.target.dataset;

                this.$emit('edit-stats-event', targetDataset.targetStat, 10);
            }
        }
    }
</script>
