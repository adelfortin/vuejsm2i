<template>
    <div>
        <h2><slot/></h2>
        <button>
            <slot name="label-button"></slot>
        </button>
    </div>
</template>
<script setup></script>
