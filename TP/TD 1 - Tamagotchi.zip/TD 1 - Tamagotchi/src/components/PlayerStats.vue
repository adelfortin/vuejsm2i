<template>
    <div class="player-stats-container">
        <p>Satiété : <span>{{ stats.satiety }}</span></p>
        <p>Energie : <span>{{ stats.stamina }}</span></p>
        <p>Distraction: <span>{{ stats.fun }}</span></p>
    </div>
</template>

<script>
    export default {
        name: 'PlayerStats',
        props : ['stats']
    }
</script>

<style>
    .player-stats-container {
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        display: flex;
        padding: 10px;
        justify-content: center;
        background: #2c3e50;
        color: white;
    }

    .player-stats-container p {
        margin: 0 15px;
        font-size: 24px;
    }
</style>
