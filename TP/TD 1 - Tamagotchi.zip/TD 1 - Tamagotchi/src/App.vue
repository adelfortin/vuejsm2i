<template>
    <img class="logo" alt="Vue logo" src="./assets/logo.png">

    <SuperButton>
        <span>HELLO</span>
        <template v-slot:label-button>
            <div>
                TEXT DE MON BOUTON

                <p>Salut c'est jb</p>
                <ul>
                    <li>Valeur 1</li>
                    <li>Valeur 2</li>
                    <li>Valeur 3</li>
                </ul>
            </div>
        </template>
    </SuperButton>
    
    <PlayerStats :stats="tamagotchi"/>
    <PlayerActions @edit-stats-event="editStats"/>
</template>

<script>
import PlayerStats from "@/components/PlayerStats.vue";
import PlayerActions from "@/components/PlayerActions.vue";
import SuperButton from "@/components/SuperButton.vue";

export default {
    name: 'App',
    components: {
        SuperButton,
        PlayerActions,
        PlayerStats
    },
    data : () => {
        return {
            cycleTimer : null,
            tamagotchi : {
                satiety : 100,
                stamina : 100,
                fun : 100
            }
        }
    },
    methods : {
        editStats(key, modificator) {
            this.tamagotchi = {...this.tamagotchi, [key] : this.tamagotchi[key] += modificator}
        }
    },
    mounted() {
        this.cycleTimer = setInterval(() => {
            this.editStats('satiety', -2);
            this.editStats('stamina', -2);
            this.editStats('fun', -2);
        }, 2000);
    },
    unmounted() {
        clearInterval(this.cycleTimer);
        this.cycleTimer = null;
    }
}
</script>

<style>
#app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
    margin-top: 60px;
}

.logo {
    position: absolute;
    left: 10px;
    top: 5px;
    z-index: 30;
    width: 40px;
}
</style>
